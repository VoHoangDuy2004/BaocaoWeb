<div class="sidebar">
    <h2>Admin Dashboard</h2>
    <ul>
        <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
        <li><a href="products.php"><i class="fas fa-box"></i> Quản lý Sản phẩm</a></li>
        <li><a href="users.php"><i class="fas fa-users"></i> Quản lý Người dùng</a></li>
        <li><a href="orders.php"><i class="fas fa-shopping-basket"></i> Quản lý Đơn hàng</a></li>
        <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a></li>
    </ul>
</div>